package nl.han.ica.PlatoBrawl;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

/**
 * Created by Jeffrey on 29-3-2018.
 * Edited by: Jeffrey & Timon
 */
public class BulletUp extends PowerUp  {
	
	
	public BulletUp(PlatoBrawl world) {
		super(new Sprite("src/main/java/nl/han/ica/PlatoBrawl/media/sprites/BulletUp.png"), world);
	}

	
	/**
     * Update het spel
     */ 
	@Override
	public void update() {
		if (world.round > 4) {
			noticeMe();
		}
	}
	
	
	/**
     * Schudt de BulletUp wanneer de speler deze niet oppakt
     */ 
	@Override
	public void noticeMe() {
		if (getySpeed() == 0) {
			setySpeed(2);
		}
		if (y<140) {
			setySpeed(2);
		}
		if (y>160) {
			setySpeed(-2);
		}
	}

	
}
