package nl.han.ica.PlatoBrawl;

import java.util.List;

import nl.han.ica.OOPDProcessingEngineHAN.Collision.ICollidableWithGameObjects;
import nl.han.ica.OOPDProcessingEngineHAN.Exceptions.TileNotFoundException;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.GameObject;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

/**
 * Created by Jeffrey on 29-3-2018.
 * Edited by: Jeffrey & Timon
 */
public class SuperBullet extends Bullet implements ICollidableWithGameObjects {

	/**
     * Constructor
     * @param player De Player die de SuperBullet schiet
     * @param world De wereld waarin de SuperBullet zich begeeft
     * @param x De x-snelheid van de kogel
     * @param f De frameindex va de kogel
     */
	public SuperBullet (Player player, PlatoBrawl world, float x, int f) {
        super(new Sprite("src/main/java/nl/han/ica/PlatoBrawl/media/sprites/SuperBullet.png"), 2, world, 25);
		setxSpeed(x);
		setCurrentFrameIndex(f);
	}
	
	
	/**
     * Checkt of SuperBullet collide met game-objecten
     * @param collidedGameObjects Lijst met game-objecten
     */
	@Override
	public void gameObjectCollisionOccurred(List<GameObject> collidedGameObjects) {
        for (GameObject go : collidedGameObjects) {
            if (go instanceof Enemy) {
            	try {
                    world.deleteGameObject(this);
                    ((Enemy) go).superBulletHit();
                } catch (TileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
	}

	/**
     * Update het spel
     */
	@Override
	public void update() {	}
	
}