package nl.han.ica.PlatoBrawl;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.GameObject;
import processing.core.PGraphics;

/**
 * Created by Jeffrey on 29-3-2018.
 * Edited by: Jeffrey & Timon
 */
public class TextObject extends GameObject {
	
	private PlatoBrawl world;
	private Player player;

	
	/**
     * Constructor
     * @param world De wereld waarin het TextObject zich begeeft
     * @param player De Player waarna een TextObject verwijst
     */
    public TextObject(PlatoBrawl world, Player player) {
    	this.world = world;
    	this.player = player;
    }

    /**
     * Update het spel
     */
    @Override
    public void update() {
    }
    
    
    /**
     * Tekent de huidige ronde en de hitpoints van Player
     * @param g De PGraphic die het object tekent
     */
    @Override
    public void draw(PGraphics g) {
        g.textAlign(g.LEFT,g.TOP);
        g.textSize(50);
        g.text("Round: " + world.round, getX() + 50, getY() + 20);
        g.textAlign(g.LEFT,g.TOP);
        g.textSize(50);
        g.text("Hitpoints: " + (int) player.getHitpoints(), 900, getY() + 20);
    }
}