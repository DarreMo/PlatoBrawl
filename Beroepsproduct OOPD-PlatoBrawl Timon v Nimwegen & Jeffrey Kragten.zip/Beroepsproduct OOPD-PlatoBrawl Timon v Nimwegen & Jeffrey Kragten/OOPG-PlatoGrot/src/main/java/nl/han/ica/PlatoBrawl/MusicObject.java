package nl.han.ica.PlatoBrawl;

import java.util.List;

import nl.han.ica.OOPDProcessingEngineHAN.Collision.ICollidableWithGameObjects;
import nl.han.ica.OOPDProcessingEngineHAN.Exceptions.TileNotFoundException;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.AnimatedSpriteObject;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.GameObject;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

public class MusicObject extends AnimatedSpriteObject implements ICollidableWithGameObjects {

	protected PlatoBrawl world;
	private long standOverStart;
	private boolean isMusic;
	
	/**
     * Constructor
     * @param world De wereld waarin het MusicObject zich begeeft
     */
	public MusicObject(PlatoBrawl world) {
		super(new Sprite("src/main/java/nl/han/ica/PlatoBrawl/media/sprites/MusicButton.png"), 4);
		this.world = world;
	}

	
	/**
     * Update het MusicObject
     */
	@Override
	public void update() {
		if (isMusic) {
			countDown();
		}
		
	}

	
	/**
     * Checkt of MusicObject collide met game-objecten
     * @param collidedGameObjects Lijst met game-objecten
     */
	@Override
	public void gameObjectCollisionOccurred(List<GameObject> collidedGameObjects) {
		for (GameObject go : collidedGameObjects) {
        	if (go instanceof Player) {
            		try { 
            			musicAnimation();
            		} catch (TileNotFoundException e) {
            			e.printStackTrace();
            		}
            	}
            }
		
	}
	
	
	/**
     * Start de muziek-animatie
     */
	private void musicAnimation() {
		standOverStart = System.currentTimeMillis();
		isMusic = true;
	}
	
	
	
	
	/**
     * Laat de Muziekknop aftellen en verwijdert deze daarna
     */
	public void countDown() {
		setCurrentFrameIndex(1);
		long currentTime = System.currentTimeMillis();
		if (currentTime - standOverStart >= 1000) {
			setCurrentFrameIndex(2);
		}
		if (currentTime - standOverStart >= 2000) {
			setCurrentFrameIndex(3);
		}
		if (currentTime - standOverStart >= 3000) {
			world.playMusic();
			world.deleteGameObject(this);
		}
	}

}
