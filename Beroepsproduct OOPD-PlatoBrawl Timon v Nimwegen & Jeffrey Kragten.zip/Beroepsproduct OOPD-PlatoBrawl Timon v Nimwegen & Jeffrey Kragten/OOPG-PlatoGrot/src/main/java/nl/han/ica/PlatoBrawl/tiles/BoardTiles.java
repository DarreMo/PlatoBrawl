package nl.han.ica.PlatoBrawl.tiles;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;
import nl.han.ica.OOPDProcessingEngineHAN.Tile.Tile;

/**
 * Created by timon on 30-3-2018.
 */
public class BoardTiles extends Tile{

    /**
     * @param sprite Image used for the tile
     */

    public BoardTiles(Sprite sprite) {
        super(sprite);
    }
}