package nl.han.ica.PlatoBrawl;

import java.util.List;

import nl.han.ica.OOPDProcessingEngineHAN.Collision.ICollidableWithGameObjects;
import nl.han.ica.OOPDProcessingEngineHAN.Exceptions.TileNotFoundException;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.GameObject;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.SpriteObject;

/**
 * Created by Jeffrey on 29-3-2018.
 * Edited by: Jeffrey & Timon
 */
public abstract class PowerUp extends SpriteObject implements ICollidableWithGameObjects {
	
	protected PlatoBrawl world;
	
	
	/**
     * Constructor
     * @param sprite De meegegeven sprite van de PowerUp
     * @param world De wereld waarin de PowerUp zich begeeft
     */
	public PowerUp(Sprite sprite, PlatoBrawl world) {
		super(sprite);
		this.world = world;
	}

	/**
     * Update het spel
     */
	@Override
	public void update() {
		
	}
		
	/**
     * Checkt of PowerUp collide met game-objecten
     * @param collidedGameObjects Lijst met game-objecten
     */
	@Override
	public void gameObjectCollisionOccurred(List<GameObject> collidedGameObjects) {
		for (GameObject go : collidedGameObjects) {
        	if (go instanceof Player) {
            		try { 
            			world.deleteGameObject(this);
            		} catch (TileNotFoundException e) {
            			e.printStackTrace();
            		}
            	}
            }
		
	}

	
	/**
     * Laat de PowerUp schudden wanneer de speler deze negeert
     */
	public void noticeMe() { }


}
