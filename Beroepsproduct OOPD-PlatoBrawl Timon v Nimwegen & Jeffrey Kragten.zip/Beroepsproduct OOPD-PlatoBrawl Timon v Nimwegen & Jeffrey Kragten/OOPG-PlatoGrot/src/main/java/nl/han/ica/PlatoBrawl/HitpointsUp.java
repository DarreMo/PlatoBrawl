package nl.han.ica.PlatoBrawl;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;

/**
 * Created by Jeffrey on 29-3-2018.
 * Edited by: Jeffrey & Timon
 */
public class HitpointsUp extends PowerUp {
	
	/**
     * Constructor
     * @param world De wereld waarin de HitpointsUp zich begeeft
     */
	public HitpointsUp(PlatoBrawl world) {
		super(new Sprite("src/main/java/nl/han/ica/PlatoBrawl/media/sprites/HitpointsUp.png"), world);
	}
	
	
	/**
     * Update het spel
     */
	@Override
	public void update() {
		if (world.round > 2) {
			noticeMe();
		}
	}
	
	
	/**
     * Schudt de HitpointsUp wanneer de speler deze niet oppakt
     */
	@Override
	public void noticeMe() {
		if (getxSpeed() == 0) {
			setxSpeed(2);
		}
		if (x < (world.getWidth()/2) - getWidth()/2 - 10) {
			setxSpeed(2);
		}
		if (x > (world.getWidth()/2)  - getWidth()/2 + 10) {
			setxSpeed(-2);
		}
	}

}